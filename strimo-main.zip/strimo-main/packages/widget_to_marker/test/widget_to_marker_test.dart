import 'package:flutter_test/flutter_test.dart';

import 'package:widget_to_marker/widget_to_marker.dart';

void main() {
  test('adds one to input values', () {});
}
