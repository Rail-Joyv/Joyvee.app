library widget_to_marker;

export 'src/widget_to_BitmapDescriptor.dart';
