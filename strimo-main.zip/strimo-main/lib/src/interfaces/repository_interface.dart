abstract class Repository {
  void init();
}