class ChatList<T> {
  // ChatList({this.list = const []});
  // final int chatId;
  // final int count;
  // final String? nextUrl;
  // final List<T> list;

}