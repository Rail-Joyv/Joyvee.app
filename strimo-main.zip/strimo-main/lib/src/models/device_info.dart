class DeviceInfo {
  const DeviceInfo(this.id, this.name);

  final String id;
  final String name;
}